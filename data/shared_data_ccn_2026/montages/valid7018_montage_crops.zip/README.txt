BabyView CCN 2026 — valid7018 montage crop archive
===================================================

JPEG thumbnails for abstract Figure 1A (25 per category).
manifest.csv columns: category, slot, jpeg_path
No subject_id or absolute filesystem paths are stored.
